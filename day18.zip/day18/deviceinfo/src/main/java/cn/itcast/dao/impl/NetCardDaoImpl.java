package cn.itcast.dao.impl;

import cn.itcast.dao.NetCardDao;
import cn.itcast.domain.Netcard;
import cn.itcast.util.JDBCUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

public class NetCardDaoImpl implements NetCardDao {
    //声明一个JDBCTemplate
    private  final JdbcTemplate template = new JdbcTemplate(JDBCUtils.getDataSource());

    @Override
    public Netcard findNetCardByID(int netcardId) {
        String sql = "select netCardID,NetCardModel,NetCardSpeed,NetCardVendor,NetCardDriver,NetCardFirmware,NetCardMacAddress from NetCardInfo where netCardID=?";
        return template.queryForObject(sql,new BeanPropertyRowMapper<Netcard>(Netcard.class),netcardId);
    }

    @Override
    public void updateNetcard(Netcard netcard) {
        String sql = "update NetCardInfo set NetCardModel = ?, NetCardSpeed=?, NetCardVendor=?, NetCardDriver=?, NetCardFirmware=?, NetCardMacAddress=? where netCardID=?";
        template.update(sql, netcard.getNetcardModel(), netcard.getNetcardSpeed(), netcard.getNetcardVendor(), netcard.getNetcardDriver(), netcard.getNetcardFirmware(), netcard.getNetcardMacAddress(), netcard.getNetcardID());
    }
}
