package cn.itcast.domain;

public class Disk {
    private int diskId;
    private String diskModel;
    private String diskVendor;
    private String diskCapacity;
    private String diskType;
    private String diskInterface;
    private String diskIdentifier;
    private String diskLabelType;

    public Disk() {
    }

    public int getDiskId() {
        return diskId;
    }

    public void setDiskId(int diskId) {
        this.diskId = diskId;
    }

    public String getDiskModel() {
        return diskModel;
    }

    public void setDiskModel(String diskModel) {
        this.diskModel = diskModel;
    }

    public String getDiskVendor() {
        return diskVendor;
    }

    public void setDiskVendor(String diskVendor) {
        this.diskVendor = diskVendor;
    }

    public String getDiskCapacity() {
        return diskCapacity;
    }

    public void setDiskCapacity(String diskCapacity) {
        this.diskCapacity = diskCapacity;
    }

    public String getDiskType() {
        return diskType;
    }

    public void setDiskType(String diskType) {
        this.diskType = diskType;
    }

    public String getDiskInterface() {
        return diskInterface;
    }

    public void setDiskInterface(String diskInterface) {
        this.diskInterface = diskInterface;
    }

    public String getDiskIdentifier() {
        return diskIdentifier;
    }

    public void setDiskIdentifier(String diskIdentifier) {
        this.diskIdentifier = diskIdentifier;
    }

    public String getDiskLabelType() {
        return diskLabelType;
    }

    public void setDiskLabelType(String diskLabelType) {
        this.diskLabelType = diskLabelType;
    }

    @Override
    public String toString() {
        return "Disk{" +
                "diskId=" + diskId +
                ", diskModel='" + diskModel + '\'' +
                ", diskVendor='" + diskVendor + '\'' +
                ", diskCapacity='" + diskCapacity + '\'' +
                ", diskType='" + diskType + '\'' +
                ", diskInterface='" + diskInterface + '\'' +
                ", diskIdentifier='" + diskIdentifier + '\'' +
                ", diskLabelType='" + diskLabelType + '\'' +
                '}';
    }
}
