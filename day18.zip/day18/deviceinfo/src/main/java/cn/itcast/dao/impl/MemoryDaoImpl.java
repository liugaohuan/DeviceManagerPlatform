package cn.itcast.dao.impl;

import cn.itcast.dao.memoryDao;
import cn.itcast.domain.Bios;
import cn.itcast.domain.Memory;
import cn.itcast.util.JDBCUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

public class MemoryDaoImpl implements memoryDao {
    //声明一个JDBCTemplate
    private  final JdbcTemplate template = new JdbcTemplate(JDBCUtils.getDataSource());

    @Override
    public Memory findMemoryByID(int memid) {
        String sql = "select memid,memoryModel,memoryVendor,memoryClock,memorySize,memoryDDR,memorySpeed from MemoryInfo where memid=?";
        return template.queryForObject(sql,new BeanPropertyRowMapper<Memory>(Memory.class),memid);
    }

    @Override
    public void updateMemoryInfo(Memory memory) {
        String sql = "update MemoryInfo set memoryModel = ?, memoryVendor = ?, memoryClock = ?, memorySize = ?, memoryDDR = ?, memorySpeed = ? where memid = ?";
        template.update(sql, memory.getMemoryModel(), memory.getMemoryVendor(), memory.getMemoryClock(), memory.getMemorySize(), memory.getMemoryDDR(), memory.getMemorySpeed(), memory.getMemId());
    }
}
