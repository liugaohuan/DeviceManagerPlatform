package cn.itcast.web.servlet;

import cn.itcast.domain.Cpu;
import cn.itcast.service.CpuService;
import cn.itcast.service.impl.CpuServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet("/findCpuInfoServlet")
public class findCpuInfoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取CPU的id
        String cpuid = request.getParameter("cpuid");
        //调用Service查询指定cpuid的cpu信息
        CpuService cs = new CpuServiceImpl();
        Cpu cpu = cs.findCpuByID(cpuid);

        //将cpu存入request
        request.setAttribute("cpu",cpu);
        //转发到cpuinfo.jsp页面中
        request.getRequestDispatcher("/cpuInfo.jsp").forward(request,response);

    }
}
