package cn.itcast.service.impl;

import cn.itcast.dao.BiosDao;
import cn.itcast.dao.impl.BiosDaoImpl;
import cn.itcast.domain.Bios;
import cn.itcast.service.BiosService;

public class BiosServiceImpl implements BiosService {

    //创建BiosDao对象
    BiosDao bd = new BiosDaoImpl();


    /**
     * 根据biosid来获取bios信息
     * @param biosID
     * @return
     */
    @Override
    public Bios findBiosByID(String biosID) {

        return bd.findBiosByID(Integer.parseInt(biosID));
    }

    @Override
    public void updateBiosInfo(Bios bios) {
        bd.updateBiosInfo(bios);
    }
}
