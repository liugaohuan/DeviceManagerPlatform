package cn.itcast.service;

import cn.itcast.domain.Memory;

/**
 * 内存管理的业务接口
 */
public interface MemoryService {
    /**
     * 根据memid获取内存信息
     * @param memid
     * @return
     */
    public Memory findMemoryByID(String memid);

    /**
     * 根据memID来更新内存信息
     * @param memory
     */
    void updateMemoryInfo(Memory memory);
}
