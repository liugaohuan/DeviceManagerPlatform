package cn.itcast.domain;

public class DisplayCard {
    private int displayCardId;
    private String displayCardModel;
    private String displayCardVendor;
    private String displayCardDriver;
    private String displayCardClock;

    public DisplayCard() {
    }

    public int getDisplayCardId() {
        return displayCardId;
    }

    public void setDisplayCardId(int displayCardId) {
        this.displayCardId = displayCardId;
    }

    public String getDisplayCardModel() {
        return displayCardModel;
    }

    public void setDisplayCardModel(String displayCardModel) {
        this.displayCardModel = displayCardModel;
    }

    public String getDisplayCardVendor() {
        return displayCardVendor;
    }

    public void setDisplayCardVendor(String displayCardVendor) {
        this.displayCardVendor = displayCardVendor;
    }

    public String getDisplayCardDriver() {
        return displayCardDriver;
    }

    public void setDisplayCardDriver(String displayCardDriver) {
        this.displayCardDriver = displayCardDriver;
    }

    public String getDisplayCardClock() {
        return displayCardClock;
    }

    public void setDisplayCardClock(String displayCardClock) {
        this.displayCardClock = displayCardClock;
    }

    @Override
    public String toString() {
        return "DisplayCard{" +
                "displayCardId=" + displayCardId +
                ", displayCardModel='" + displayCardModel + '\'' +
                ", displayCardVendor='" + displayCardVendor + '\'' +
                ", displayCardDriver='" + displayCardDriver + '\'' +
                ", displayCardClock='" + displayCardClock + '\'' +
                '}';
    }
}
