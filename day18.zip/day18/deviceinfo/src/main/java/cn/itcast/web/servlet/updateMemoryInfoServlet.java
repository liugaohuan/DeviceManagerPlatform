package cn.itcast.web.servlet;

import cn.itcast.domain.Memory;
import cn.itcast.service.MemoryService;
import cn.itcast.service.impl.MemoryServiceImpl;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

@WebServlet("/updateMemoryInfoServlet")
public class updateMemoryInfoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置编码格式
        request.setCharacterEncoding("UTF-8");

        //2.获取参数，返回参数Map集合
        Map<String, String[]> parameterMap = request.getParameterMap();

        //创建Memory对象
        Memory memory = new Memory();

        //将参数集合封装成memory对象
        try {
            BeanUtils.populate(memory, parameterMap);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }


        //调用MemoryService来更新Memory信息
        MemoryService ms = new MemoryServiceImpl();
        ms.updateMemoryInfo(memory);

        //跳转到deviceListServlet
        response.sendRedirect(request.getContextPath()+"/FindDeviceByPageServlet?currentPage=1&rows=5");

    }
}
