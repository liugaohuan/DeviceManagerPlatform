package cn.itcast.web.servlet;

import cn.itcast.domain.Disk;
import cn.itcast.service.DiskService;
import cn.itcast.service.impl.DiskServiceImpl;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

@WebServlet("/updateDiskInfoServlet")
public class updateDiskInfoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置编码格式
        request.setCharacterEncoding("UTF-8");

        //获取参数集合
        Map<String, String[]> parameterMap = request.getParameterMap();

        //封装成Disk对象
        Disk disk = new Disk();

        try {
            BeanUtils.populate(disk, parameterMap);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        //调用Service来更新disk信息
        DiskService ds = new DiskServiceImpl();
        ds.updateDiskInfo(disk);

        //共享数据，跳转到deviceListServlet
        response.sendRedirect(request.getContextPath()+"/FindDeviceByPageServlet?currentPage=1&rows=5");
    }
}
