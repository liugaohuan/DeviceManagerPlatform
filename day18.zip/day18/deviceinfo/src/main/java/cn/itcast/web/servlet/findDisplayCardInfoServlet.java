package cn.itcast.web.servlet;

import cn.itcast.domain.DisplayCard;
import cn.itcast.service.DisplayCardService;
import cn.itcast.service.impl.DisplayCardServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet("/findDisplayCardInfoServlet")
public class findDisplayCardInfoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //根据discardid来获取显卡信息
        String discardid = request.getParameter("discardid");

        //创建DisplayCardService对象
        DisplayCardService dcs = new DisplayCardServiceImpl();
        DisplayCard displayCard = dcs.findDisplayCardByID(discardid);

        //将displayCard对象存入request域中
        request.setAttribute("displayCard",displayCard);

        //request请求转发至/displayCardInfo.jsp中
        request.getRequestDispatcher("/displayCardInfo.jsp").forward(request,response);
    }
}
