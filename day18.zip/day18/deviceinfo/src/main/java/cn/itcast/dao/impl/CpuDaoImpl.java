package cn.itcast.dao.impl;

import cn.itcast.dao.CpuDao;
import cn.itcast.domain.Cpu;
import cn.itcast.util.JDBCUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

public class CpuDaoImpl implements CpuDao {
    //声明一个JDBCTemplate
    private  final JdbcTemplate template = new JdbcTemplate(JDBCUtils.getDataSource());

    @Override
    public Cpu findCpuByID(int cpuid) {
        //定义sql语句
        String sql = "select cpuid, CpuModel, MHz, Cores, NUMAnodes, Vendor, L1dcache, L1icache, L2cache, L3cache from CpuInfo where cpuid = ? ";
        return template.queryForObject(sql,new BeanPropertyRowMapper<Cpu>(Cpu.class),cpuid);
    }

    @Override
    public void updateCpuInfo(Cpu cpu) {
        //定义sql语句
        String sql = "update CpuInfo set CpuModel = ?, MHz = ?, Cores = ?, NUMAnodes = ?, Vendor = ?, L1dcache = ?, L1icache = ?, L2cache = ?, L3cache = ? where cpuid=?";
        template.update(sql, cpu.getCpuModel(), cpu.getmHz(), cpu.getCores(), cpu.getNumaNodes(), cpu.getVendor(), cpu.getL1dCache(), cpu.getL1iCache(), cpu.getL2Cache(), cpu.getL3Cache(), cpu.getCpuId());
    }
}
