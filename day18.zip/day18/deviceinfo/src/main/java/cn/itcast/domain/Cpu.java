package cn.itcast.domain;

public class Cpu {
    private int cpuId;
    private String cpuModel;
    private String mHz;
    private String cores;
    private String numaNodes;
    private String vendor;
    private String l1dCache;
    private String l1iCache;
    private String l2Cache;
    private String l3Cache;

    public Cpu() {
    }


    public int getCpuId() {
        return cpuId;
    }

    public void setCpuId(int cpuId) {
        this.cpuId = cpuId;
    }

    public String getCpuModel() {
        return cpuModel;
    }

    public void setCpuModel(String cpuModel) {
        this.cpuModel = cpuModel;
    }

    public String getmHz() {
        return mHz;
    }

    public void setmHz(String mHz) {
        this.mHz = mHz;
    }

    public String getCores() {
        return cores;
    }

    public void setCores(String cores) {
        this.cores = cores;
    }

    public String getNumaNodes() {
        return numaNodes;
    }

    public void setNumaNodes(String numaNodes) {
        this.numaNodes = numaNodes;
    }

    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public String getL1dCache() {
        return l1dCache;
    }

    public void setL1dCache(String l1dCache) {
        this.l1dCache = l1dCache;
    }

    public String getL1iCache() {
        return l1iCache;
    }

    public void setL1iCache(String l1iCache) {
        this.l1iCache = l1iCache;
    }

    public String getL2Cache() {
        return l2Cache;
    }

    public void setL2Cache(String l2Cache) {
        this.l2Cache = l2Cache;
    }

    public String getL3Cache() {
        return l3Cache;
    }

    public void setL3Cache(String l3Cache) {
        this.l3Cache = l3Cache;
    }

    @Override
    public String toString() {
        return "Cpu{" +
                "cpuId=" + cpuId +
                ", cpuModel='" + cpuModel + '\'' +
                ", mHz='" + mHz + '\'' +
                ", cores=" + cores +
                ", numaNodes=" + numaNodes +
                ", vendor='" + vendor + '\'' +
                ", l1dCache='" + l1dCache + '\'' +
                ", l1iCache='" + l1iCache + '\'' +
                ", l2Cache='" + l2Cache + '\'' +
                ", l3Cache='" + l3Cache + '\'' +
                '}';
    }
}
