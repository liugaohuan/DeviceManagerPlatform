package cn.itcast.util;

public class ExecuteCommands {
    public static final String MACHINE_VENDOR = "sudo dmidecode -t baseboard | grep Manufacturer |awk '{print $NF}'";
    public static final String MACHINE_MODEL = "sudo dmidecode -t baseboard |grep Product |awk '{print $NF}'";
    public static final String OS_VERSION = "cat /etc/product-info";
    public static final String CPU_MODEL = "lscpu |grep Model\\ name |awk '{for(i=3;i<=NF;++i) printf $i \" \";printf \"\\n\"}'";
    public static final String MEMORY_MODEL = "sudo dmidecode -t memory |grep Manufacturer |head -n1 |awk '{print $NF}'";
    public static final String MEMORY_SIZE = "sudo free -mh |grep Mem |awk '{print $2}'";
    public static final String BIOS_VENDOR = "sudo dmidecode -t bios |grep Vendor |awk '{for(i=2;i<=NF;++i) printf $i \" \";printf \"\\n\"}'";
    public static final String NETWORK_MODEL = "sudo lspci |grep Ethernet |awk '{for(i=4;i<=NF;++i) printf $i \" \";printf \"\\n\"}'";
    public static final String DISPLAY_CARD_MODEL = "sudo lspci |grep VGA |awk '{for(i=5;i<=NF;++i) printf $i \" \";printf \"\\n\"}'";
    public static final String DISK_MODEL = "sudo fdisk -l |grep Disk\\ model";


    public static final String CPU_MHZ = "lscpu |grep CPU\\ MHz |awk '{print $NF}'";
    public static final String CPU_CORES = "cat /proc/cpuinfo |grep processor |wc -l";
    public static final String CPU_NUMANODES = "lscpu  |grep NUMA\\ node\\(s\\) |awk '{print $NF}'";
    public static final String CPU_VENDOR = "lscpu |grep Vendor |awk '{print $NF}'";
    public static final String CPU_L1DCache = "lscpu |grep -i L1d\\ cache |awk '{for(i=3;i<=NF;++i) printf $i \" \";printf \"\\n\"}'";
    public static final String CPU_L1ICache = "lscpu |grep -i L1i\\ cache |awk '{for(i=3;i<=NF;++i) printf $i \" \";printf \"\\n\"}'";
    public static final String CPU_L2Cache =  "lscpu |grep -i L2\\ cache |awk '{for(i=3;i<=NF;++i) printf $i \" \";printf \"\\n\"}'";
    public static final String CPU_L3Cache =  "lscpu |grep -i L3\\ cache |awk '{for(i=3;i<=NF;++i) printf $i \" \";printf \"\\n\"}'";

    public static final String BIOS_VERSION = "sudo dmidecode -t bios |grep Version|awk '{for(i=2;i<=NF;++i) printf $i \" \";printf \"\\n\"}'";
    public static final String BIOS_RELEASEDATE = " sudo dmidecode -t bios |grep Release\\ Date|awk '{for(i=3;i<=NF;++i) printf $i \" \";printf \"\\n\"}'";
    public static final String BIOS_ROMSIZE = "sudo dmidecode -t bios |grep ROM\\ Size |awk '{for(i=3;i<=NF;++i) printf $i \" \";printf \"\\n\"}'";
    public static final String BIOS_ADDRESS = "sudo dmidecode -t bios |grep Address |awk '{for(i=2;i<=NF;++i) printf $i \" \";printf \"\\n\"}'";


    public static final String DISK_VENDOR = "sudo lshw -C disk |grep vendor |awk '{for(i=2;i<=NF;++i) printf $i \" \";printf  \"\\n\"}'";
    public static final String DISK_CAPACITY = "sudo lshw -C disk |grep size: |awk '{for(i=2;i<=NF;++i) printf $i \"\";printf  \"\\n\"}'";
    public static final String DISK_IDENTIFIER = "sudo fdisk -l |grep Disk\\ identifier |awk '{print $NF}'";
    public static final String DISK_LABEL_TYPE = "sudo fdisk -l |grep Disklabel\\ type |awk '{print $NF}'";
    public static final String DISK_TYPE = "";
    public static final String DISK_INTERFACE = "";


    public static final String MEMORY_VENDOR = "sudo dmidecode -t memory |grep Manufacturer |head -n1 |awk '{print $NF}'";
    public static final String MEMORY_CLOCK = "";
    public static final String MEMORY_DDR = " sudo dmidecode -t memory |grep Type |grep -v Error\\ Correction\\ Type |grep -v Detail |head -n1 |awk '{print $NF}'";
    public static final String MEMORY_SPEED = "sudo dmidecode -t memory |grep Speed |grep -v Configured\\ Memory\\ Speed |head -n1 ";


    public static final String NETCARD_SPEED = "sudo lshw -C NETWORK |grep capacity: |awk '{print $NF}'";
    public static final String NETCARD_VENDOR =" sudo lshw -C NETWORK |grep vendor | awk '{for(i=2;i<=NF;++i) printf $i \"\";printf  \"\\n\"}'";
    public static final String NETCARD_DRIVER = " sudo lshw -C NETWORK |grep driver= | awk '{print $4}'";
    public static final String NETCARD_Firmware = "sudo lshw -C NETWORK |grep firmware | awk '{print $6,$7}'";
    public static final String NETCARD_MACADDRESS = "sudo lshw -C NETWORK |grep serial";


    public static final String DISPLAY_CARD_Vendor = "sudo lshw -c display |grep vendor |awk '{print $NF}'";
    public static final String DISPLAY_CARD_DRIVER = "sudo lshw -c display |grep driver";
    public static final String DISPLAY_CARD_CLOCK = "sudo lshw -c display |grep clock |awk '{print $NF}'";

}
