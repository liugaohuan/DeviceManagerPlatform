package cn.itcast.service.impl;

import cn.itcast.dao.CpuDao;
import cn.itcast.dao.impl.CpuDaoImpl;
import cn.itcast.domain.Cpu;
import cn.itcast.service.CpuService;

public class CpuServiceImpl implements CpuService {

    //创建CpuDao实现类对象
    CpuDao cd = new CpuDaoImpl();

    /**
     *根据cpuid来获取cpu信息
     * @param cpuid
     * @return
     */
    @Override
    public Cpu findCpuByID(String cpuid) {
        //返回查询结果
        return cd.findCpuByID(Integer.parseInt(cpuid));
    }

    @Override
    public void updateCpuInfo(Cpu cpu) {
        cd.updateCpuInfo(cpu);
    }
}
