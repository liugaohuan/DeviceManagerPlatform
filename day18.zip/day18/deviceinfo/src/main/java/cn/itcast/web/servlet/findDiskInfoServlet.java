package cn.itcast.web.servlet;


import cn.itcast.domain.Disk;
import cn.itcast.service.DiskService;
import cn.itcast.service.impl.DiskServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/findDiskInfoServlet")
public class findDiskInfoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取disk的id
        String diskid = request.getParameter("diskid");
        //调用Service查询指定Model的disk信息
        DiskService ds = new DiskServiceImpl();
        Disk disk = ds.findDiskByID(diskid);

        //将disk存入request
        request.setAttribute("disk",disk);
        //转发到diskinfo.jsp页面中
        request.getRequestDispatcher("/diskInfo.jsp").forward(request,response);

    }
}
