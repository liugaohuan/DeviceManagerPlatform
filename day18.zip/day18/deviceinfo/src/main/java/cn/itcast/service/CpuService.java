package cn.itcast.service;

import cn.itcast.domain.Cpu;

/**
 * CPU管理的业务接口
 */
public interface CpuService {

    /**
     * 根据cpuid查询cpu信息
     * @param cpuid
     * @return
     */

    public Cpu findCpuByID(String cpuid);

    /**
     * 更新cpu信息
     * @param cpu
     */
    void updateCpuInfo(Cpu cpu);
}
