package cn.itcast.web.servlet;

import cn.itcast.domain.Device;
import cn.itcast.domain.PageBean;
import cn.itcast.service.DeviceService;
import cn.itcast.service.impl.DeviceServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.Map;

@WebServlet("/FindDeviceByPageServlet")
public class FindDeviceByPageServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        //接收当前页码请求参数
        String currentPage = request.getParameter("currentPage");

        //接受每页显示行数请求参数
        String rows = request.getParameter("rows");

        if(currentPage == null || "".equals(currentPage)){
            currentPage = "1";
        }
        if(rows == null || "".equals(rows)){
            rows = "5";
        }

        //获取条件查询参数
        Map<String, String[]> conditions = request.getParameterMap();

        //调用service查询PageBean
        DeviceService ds = new DeviceServiceImpl();
        PageBean<Device> pb = ds.findDeviceByPage(currentPage, rows, conditions);

        //将PageBean存入request域中
        request.setAttribute("pb", pb);

        //转发到list.jsp
        request.getRequestDispatcher("/list.jsp").forward(request,response);
    }
}
