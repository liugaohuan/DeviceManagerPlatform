package cn.itcast.dao.impl;

import cn.itcast.dao.BiosDao;
import cn.itcast.domain.Bios;
import cn.itcast.util.JDBCUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

public class BiosDaoImpl implements BiosDao {
    //声明一个JDBCTemplate
    private  final JdbcTemplate template = new JdbcTemplate(JDBCUtils.getDataSource());

    @Override
    public Bios findBiosByID(int biosID) {
        //定义sql语句
        String sql = "select biosID, BiosVendor, BiosVersion, ReleaseDate, RowSize, Address from BiosInfo where biosID = ? ";
        return template.queryForObject(sql,new BeanPropertyRowMapper<Bios>(Bios.class),biosID);
    }

    @Override
    public void updateBiosInfo(Bios bios) {
        //定义sql语句
        String sql = "update BiosInfo set  biosVendor = ?, BiosVersion = ?, ReleaseDate = ?, RowSize = ?, Address=? where biosid=?";
        template.update(sql, bios.getBiosVendor(), bios.getBiosVersion(), bios.getReleaseDate(), bios.getRowSize(), bios.getAddress(), bios.getBiosId());
    }
}
