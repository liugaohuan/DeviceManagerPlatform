package cn.itcast.service;

import cn.itcast.domain.Netcard;

public interface NetCardService {
    /**
     * 根据netcardid查询网卡信息
     * @param netcardid
     * @return
     */
    Netcard findNetCardByID(String netcardid);

    /**
     * 修改网卡信息
     * @param netcard
     */
    void updateNetcard(Netcard netcard);
}
