package cn.itcast.dao;

import cn.itcast.domain.Netcard;

public interface NetCardDao {
    /**
     * 根据netCardID查询网卡信息
     * @param netCardID
     * @return
     */
    Netcard findNetCardByID(int netCardID);

    /**
     * 更新网卡信息接口
     * @param netcard
     */
    void updateNetcard(Netcard netcard);
}
