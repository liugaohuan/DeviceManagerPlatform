package cn.itcast.web.servlet;

import cn.itcast.domain.Netcard;
import cn.itcast.service.NetCardService;
import cn.itcast.service.impl.NetCardServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet("/findNetCardInfoServlet")
public class findNetCardInfoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //根据netCardID来查询NetCard信息
        String netcardid = request.getParameter("netcardid");

        //创建NetCardService实现类对象
        NetCardService ncs = new NetCardServiceImpl();

        Netcard netcard = ncs.findNetCardByID(netcardid);
        request.setAttribute("netcard",netcard);

        //转发到netcardInfo.jsp页面中
        request.getRequestDispatcher("/netcardInfo.jsp").forward(request,response);
    }
}
