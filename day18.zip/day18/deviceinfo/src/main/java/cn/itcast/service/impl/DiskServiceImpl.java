package cn.itcast.service.impl;

import cn.itcast.dao.DiskDao;
import cn.itcast.dao.impl.DiskDaoImpl;
import cn.itcast.domain.Device;
import cn.itcast.domain.Disk;
import cn.itcast.service.DiskService;

public class DiskServiceImpl implements DiskService {
    //创建DiskDao实现类对象
    DiskDao dd = new DiskDaoImpl();

    /**
     * 根据diskid来获取磁盘信息
     * @param diskid
     * @return
     */
    @Override
    public Disk findDiskByID(String diskid) {
        return dd.findDiskByID(Integer.parseInt(diskid));
    }

    @Override
    public void updateDiskInfo(Disk disk) {
        dd.updateDiskInfo(disk);
    }

}
