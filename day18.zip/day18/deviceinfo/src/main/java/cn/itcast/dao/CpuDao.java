package cn.itcast.dao;

import cn.itcast.domain.Cpu;

/**
 * cpu操作的DAO
 */
public interface CpuDao {
    /**
     * 根据cpuid查询cpu详细信息
     * @param cpuid
     * @return
     */
    Cpu findCpuByID(int cpuid);

    /**
     * 更新cpu信息
     * @param cpu
     */
    void updateCpuInfo(Cpu cpu);
}
