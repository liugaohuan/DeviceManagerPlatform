package cn.itcast.web.servlet;

import cn.itcast.domain.Bios;
import cn.itcast.service.BiosService;
import cn.itcast.service.impl.BiosServiceImpl;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

@WebServlet("/updateBiosInfoServlet")
public class updateBiosInfoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置编码格式
        request.setCharacterEncoding("UTF-8");

        //获取参数集合
        Map<String, String[]> parameterMap = request.getParameterMap();

        //封装成Bios对象
        Bios bios = new Bios();

        try {
            BeanUtils.populate(bios, parameterMap);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        //调用BiosService来更新Bios信息
        BiosService bs = new BiosServiceImpl();
        bs.updateBiosInfo(bios);

        //共享数据并跳转到deviceList.jsp页面
        response.sendRedirect(request.getContextPath()+"/FindDeviceByPageServlet?currentPage=1&rows=5");

    }
}
