package cn.itcast.web.servlet;

import cn.itcast.domain.Device;
import cn.itcast.service.DeviceService;
import cn.itcast.service.impl.DeviceServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet("/deleteDeviceServlet")
public class deleteDeviceServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.设置编码
        request.setCharacterEncoding("utf-8");

        //2. 通过id来获取device信息
        String deviceId = request.getParameter("deviceid");

        //3. 调用searchDeviceById查询指定deviceId的设备信息
        DeviceService ds = new DeviceServiceImpl();
        Device device = ds.searchDeviceById(deviceId);
        
        //4. 调用deleteDevice删除指定的设备信息
        ds.deleteDevice(device);

        //5. 跳转到deviceListServlet
        response.sendRedirect(request.getContextPath()+"/FindDeviceByPageServlet?currentPage=1&rows=5");
    }
}
