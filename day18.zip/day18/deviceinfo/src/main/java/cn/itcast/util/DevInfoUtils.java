package cn.itcast.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import cn.itcast.domain.*;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class DevInfoUtils {
    public static final String[] DEVCOMMANDS = {ExecuteCommands.MACHINE_VENDOR, ExecuteCommands.MACHINE_MODEL, ExecuteCommands.OS_VERSION, ExecuteCommands.CPU_MODEL, ExecuteCommands.MEMORY_MODEL, ExecuteCommands.MEMORY_SIZE, ExecuteCommands.BIOS_VENDOR, ExecuteCommands.NETWORK_MODEL, ExecuteCommands.DISPLAY_CARD_MODEL, ExecuteCommands.DISK_MODEL};
    public static final String[] BIOSCOMMANDS = {ExecuteCommands.BIOS_VERSION,ExecuteCommands.BIOS_RELEASEDATE, ExecuteCommands.BIOS_ROMSIZE,ExecuteCommands.BIOS_ADDRESS};
    public static final String[] CPUCOMMANDS = {ExecuteCommands.CPU_MHZ,ExecuteCommands.CPU_CORES,ExecuteCommands.CPU_NUMANODES, ExecuteCommands.CPU_VENDOR,ExecuteCommands.CPU_L1ICache,ExecuteCommands.CPU_L1ICache,ExecuteCommands.CPU_L1DCache,ExecuteCommands.CPU_L2Cache,ExecuteCommands.CPU_L3Cache};
    public static final String[] DISKCOMMANDS = {ExecuteCommands.DISK_CAPACITY,ExecuteCommands.DISK_IDENTIFIER,ExecuteCommands.DISK_INTERFACE,ExecuteCommands.DISK_TYPE,ExecuteCommands.DISK_LABEL_TYPE,ExecuteCommands.DISK_VENDOR};
    public static final String[] NETWORKCOMMANDS = {ExecuteCommands.NETCARD_DRIVER,ExecuteCommands.NETCARD_Firmware,ExecuteCommands.NETCARD_MACADDRESS,ExecuteCommands.NETCARD_SPEED,ExecuteCommands.NETCARD_VENDOR};
    public static final String[] DISPLAYCOMMANDS = {ExecuteCommands.DISPLAY_CARD_Vendor,ExecuteCommands.DISPLAY_CARD_DRIVER,ExecuteCommands.DISPLAY_CARD_CLOCK};
    public static final String[] MEMORYCOMMANDS = {ExecuteCommands.MEMORY_VENDOR,ExecuteCommands.MEMORY_SPEED,ExecuteCommands.MEMORY_CLOCK,ExecuteCommands.MEMORY_DDR};


    private static Session session;

    /**
     * 连接到指定的HOST
     *
     * @return isConnect
     * @throws JSchException JSchException
     */
    public static boolean connect(String user, String passwd, String host) {
        JSch jsch = new JSch();
        try {
            session = jsch.getSession(user, host, 22);
            session.setPassword(passwd);
            java.util.Properties config = new java.util.Properties();
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);
            session.connect();
        } catch (JSchException e) {
            e.printStackTrace();
            System.out.println("ssh connect error !");
            return false;
        }
        return true;
    }

    /**
     * 远程连接Linux服务器执行相关的命令
     *
     * @return 最终命令返回信息
     */
    public static Device getDevInfo(String[] commands) {
        Device device = new Device();
        StringBuilder stringBuffer;
        BufferedReader reader = null;
        Channel channel = null;
        try {
            for (String command : commands) {
                stringBuffer = new StringBuilder();
                channel = session.openChannel("exec");
                ((ChannelExec) channel).setCommand(command);
                channel.setInputStream(null);
                ((ChannelExec) channel).setErrStream(System.err);
                channel.connect();
                InputStream in = channel.getInputStream();
                reader = new BufferedReader(new InputStreamReader(in));
                String buf;
                while ((buf = reader.readLine()) != null) {
                    stringBuffer.append(buf.trim()).append(" ");
                }
                //每个命令存储自己返回数据-用于后续对返回数据进行处理
                if (command.contains("sudo dmidecode -t baseboard | grep Manufacturer")) {
                    device.setDevVendor(stringBuffer.toString());

                }
                if (command.contains("sudo dmidecode -t baseboard |grep Product")) {
                    device.setDevModel(stringBuffer.toString());
                }
                if (command.contains("product-info")) {
                    device.setOsVersion(stringBuffer.toString());
                }
                if (command.contains("lscpu |grep Model\\ name |awk '{for(i=3;i<=NF;++i) printf $i \" \";printf \"\\n\"}'")) {
                    device.setCpuModel(stringBuffer.toString());
                }
                if (command.contains("sudo dmidecode -t memory |grep Manufacturer")) {
                    device.setMemoryModel(stringBuffer.toString());
                }
                if (command.contains("sudo free -mh |grep Mem")) {
                    device.setMemorySize(stringBuffer.toString());
                }
                if (command.contains("sudo dmidecode -t bios |grep Vendor ")) {
                    device.setBiosVendor(stringBuffer.toString());
                }
                if (command.contains("sudo lspci |grep Ethernet")) {
                    device.setNetcardModel(stringBuffer.toString());
                }
                if (command.contains("sudo lspci |grep VGA ")) {
                    device.setDisplayCardModel(stringBuffer.toString());
                }
                if (command.contains("sudo fdisk -l |grep Disk\\ model")) {
                    device.setDiskModel(stringBuffer.toString());
                }
            }
        } catch (IOException | JSchException e) {
            e.printStackTrace();
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (channel != null) {
                channel.disconnect();
            }
        }
        return device;
    }

    public static Cpu getCpuInfo(String[] commands) {
        Cpu cpu = new Cpu();
        StringBuilder stringBuffer;
        BufferedReader reader = null;
        Channel channel = null;
        try {
            for (String command : commands) {
                stringBuffer = new StringBuilder();
                channel = session.openChannel("exec");
                ((ChannelExec) channel).setCommand(command);
                channel.setInputStream(null);
                ((ChannelExec) channel).setErrStream(System.err);
                channel.connect();
                InputStream in = channel.getInputStream();
                reader = new BufferedReader(new InputStreamReader(in));
                String buf;
                while ((buf = reader.readLine()) != null) {
                    stringBuffer.append(buf.trim()).append(" ");
                }
                //每个命令存储自己返回数据-用于后续对返回数据进行处理
                if (command.contains("lscpu |grep Vendor |awk '{print $NF}'")) {
                    cpu.setVendor(stringBuffer.toString());
                }
                if (command.contains("lscpu |grep CPU\\ MHz |awk '{print $NF}'")) {
                    cpu.setmHz(stringBuffer.toString());
                }
                if (command.contains("cat /proc/cpuinfo |grep processor |wc -l")) {
                    cpu.setCores(stringBuffer.toString());
                }
                if (command.contains("lscpu  |grep NUMA\\ node\\(s\\) |awk '{print $NF}'")) {
                    cpu.setNumaNodes(stringBuffer.toString());
                }
                if (command.contains("lscpu |grep -i L1d\\ cache |awk '{for(i=3;i<=NF;++i) printf $i \" \";printf \"\\n\"}'")) {
                    cpu.setL1dCache(stringBuffer.toString());
                }
                if (command.contains("lscpu |grep -i L1i\\ cache |awk '{for(i=3;i<=NF;++i) printf $i \" \";printf \"\\n\"}'")) {
                    cpu.setL1iCache(stringBuffer.toString());
                }
                if (command.contains("lscpu |grep -i L2\\ cache |awk '{for(i=3;i<=NF;++i) printf $i \" \";printf \"\\n\"}'")) {
                    cpu.setL2Cache(stringBuffer.toString());
                }
                if (command.contains("lscpu |grep -i L3\\ cache |awk '{for(i=3;i<=NF;++i) printf $i \" \";printf \"\\n\"}'")) {
                   cpu.setL3Cache(stringBuffer.toString());
                }
            }
        } catch (IOException | JSchException e) {
            e.printStackTrace();
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (channel != null) {
                channel.disconnect();
            }
        }
        return cpu;
    }

    public static Bios getBiosInfo(String[] commands) {
        Bios bios = new Bios();
        StringBuilder stringBuffer;
        BufferedReader reader = null;
        Channel channel = null;
        try {
            for (String command : commands) {
                stringBuffer = new StringBuilder();
                channel = session.openChannel("exec");
                ((ChannelExec) channel).setCommand(command);
                channel.setInputStream(null);
                ((ChannelExec) channel).setErrStream(System.err);
                channel.connect();
                InputStream in = channel.getInputStream();
                reader = new BufferedReader(new InputStreamReader(in));
                String buf;
                while ((buf = reader.readLine()) != null) {
                    stringBuffer.append(buf.trim()).append(" ");
                }
                //每个命令存储自己返回数据-用于后续对返回数据进行处理
                if (command.contains("sudo dmidecode -t bios |grep Version|awk '{for(i=2;i<=NF;++i) printf $i \" \";printf \"\\n\"}'")) {
                    bios.setBiosVersion(stringBuffer.toString());
                }
                if (command.contains("sudo dmidecode -t bios |grep Release\\ Date|awk '{for(i=3;i<=NF;++i) printf $i \" \";printf \"\\n\"}'")) {
                    bios.setReleaseDate(stringBuffer.toString());
                }
                if (command.contains("sudo dmidecode -t bios |grep ROM\\ Size |awk '{for(i=3;i<=NF;++i) printf $i \" \";printf \"\\n\"}'")) {
                    bios.setRowSize(stringBuffer.toString());
                }
                if (command.contains("sudo dmidecode -t bios |grep Address |awk '{for(i=2;i<=NF;++i) printf $i \" \";printf \"\\n\"}'")) {
                    bios.setRowSize(stringBuffer.toString());
                }
            }
        } catch (IOException | JSchException e) {
            e.printStackTrace();
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (channel != null) {
                channel.disconnect();
            }
        }
        return bios;
    }

    public static Disk getDiskInfo(String[] commands) {
       Disk disk = new Disk();
        StringBuilder stringBuffer;
        BufferedReader reader = null;
        Channel channel = null;
        try {
            for (String command : commands) {
                stringBuffer = new StringBuilder();
                channel = session.openChannel("exec");
                ((ChannelExec) channel).setCommand(command);
                channel.setInputStream(null);
                ((ChannelExec) channel).setErrStream(System.err);
                channel.connect();
                InputStream in = channel.getInputStream();
                reader = new BufferedReader(new InputStreamReader(in));
                String buf;
                while ((buf = reader.readLine()) != null) {
                    stringBuffer.append(buf.trim()).append(" ");
                }
                //每个命令存储自己返回数据-用于后续对返回数据进行处理
                if (command.contains("sudo lshw -C disk |grep vendor |awk '{for(i=2;i<=NF;++i) printf $i \" \";printf  \"\\n\"}'")) {
                    disk.setDiskVendor(stringBuffer.toString());
                }
                if (command.contains("sudo lshw -C disk |grep size: |awk '{for(i=2;i<=NF;++i) printf $i \"\";printf  \"\\n\"}'")) {
                    disk.setDiskCapacity(stringBuffer.toString());
                }
                if (command.contains("sudo fdisk -l |grep Disk\\ identifier |awk '{print $NF}'")) {
                    disk.setDiskIdentifier(stringBuffer.toString());
                }
                if (command.contains("sudo fdisk -l |grep Disklabel\\ type |awk '{print $NF}'")) {
                    disk.setDiskLabelType(stringBuffer.toString());
                }
            }
        } catch (IOException | JSchException e) {
            e.printStackTrace();
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (channel != null) {
                channel.disconnect();
            }
        }
        return disk;
    }

    public static Memory getMemoryInfo(String[] commands) {
        Memory memory = new Memory();
        StringBuilder stringBuffer;
        BufferedReader reader = null;
        Channel channel = null;
        try {
            for (String command : commands) {
                stringBuffer = new StringBuilder();
                channel = session.openChannel("exec");
                ((ChannelExec) channel).setCommand(command);
                channel.setInputStream(null);
                ((ChannelExec) channel).setErrStream(System.err);
                channel.connect();
                InputStream in = channel.getInputStream();
                reader = new BufferedReader(new InputStreamReader(in));
                String buf;
                while ((buf = reader.readLine()) != null) {
                    stringBuffer.append(buf.trim()).append(" ");
                }
                //每个命令存储自己返回数据-用于后续对返回数据进行处理
                if (command.contains("sudo dmidecode -t memory |grep Manufacturer |head -n1 |awk '{print $NF}'")) {
                    memory.setMemoryVendor(stringBuffer.toString());
                }
                if (command.contains("sudo dmidecode -t memory |grep Type |grep -v Error\\ Correction\\ Type |grep -v Detail |head -n1 |awk '{print $NF}'")) {
                    memory.setMemoryDDR(stringBuffer.toString());
                }
                if (command.contains("sudo dmidecode -t memory |grep Speed |grep -v Configured\\ Memory\\ Speed |head -n1 ")) {
                    memory.setMemorySpeed(stringBuffer.toString());
                }
            }
        } catch (IOException | JSchException e) {
            e.printStackTrace();
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (channel != null) {
                channel.disconnect();
            }
        }
        return memory;
    }
    public static Netcard getNetcardInfo(String[] commands) {
        Netcard netcard = new Netcard();
        StringBuilder stringBuffer;
        BufferedReader reader = null;
        Channel channel = null;
        try {
            for (String command : commands) {
                stringBuffer = new StringBuilder();
                channel = session.openChannel("exec");
                ((ChannelExec) channel).setCommand(command);
                channel.setInputStream(null);
                ((ChannelExec) channel).setErrStream(System.err);
                channel.connect();
                InputStream in = channel.getInputStream();
                reader = new BufferedReader(new InputStreamReader(in));
                String buf;
                while ((buf = reader.readLine()) != null) {
                    stringBuffer.append(buf.trim()).append(" ");
                }
                //每个命令存储自己返回数据-用于后续对返回数据进行处理
                if (command.contains("sudo lshw -C NETWORK |grep capacity: |awk '{print $NF}'")) {
                   netcard.setNetcardSpeed(stringBuffer.toString());
                }
                if (command.contains("sudo lshw -C NETWORK |grep vendor | awk '{for(i=2;i<=NF;++i) printf $i \"\";printf  \"\\n\"}'")) {
                    netcard.setNetcardVendor(stringBuffer.toString());
                }
                if (command.contains("sudo lshw -C NETWORK |grep driver= | awk '{print $4}'")) {
                    netcard.setNetcardDriver(stringBuffer.toString());
                }
                if (command.contains("sudo lshw -C NETWORK |grep firmware | awk '{print $6,$7}'")) {
                    netcard.setNetcardFirmware(stringBuffer.toString());
                }
                if (command.contains("sudo lshw -C NETWORK |grep serial")) {
                    netcard.setNetcardMacAddress(stringBuffer.toString());
                }
            }
        } catch (IOException | JSchException e) {
            e.printStackTrace();
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (channel != null) {
                channel.disconnect();
            }
        }
        return netcard;
    }

    public static DisplayCard getDisplayCardInfo(String[] commands) {
        DisplayCard displayCard = new DisplayCard();
        StringBuilder stringBuffer;
        BufferedReader reader = null;
        Channel channel = null;
        try {
            for (String command : commands) {
                stringBuffer = new StringBuilder();
                channel = session.openChannel("exec");
                ((ChannelExec) channel).setCommand(command);
                channel.setInputStream(null);
                ((ChannelExec) channel).setErrStream(System.err);
                channel.connect();
                InputStream in = channel.getInputStream();
                reader = new BufferedReader(new InputStreamReader(in));
                String buf;
                while ((buf = reader.readLine()) != null) {
                    stringBuffer.append(buf.trim()).append(" ");
                }
                //每个命令存储自己返回数据-用于后续对返回数据进行处理
                if (command.contains("sudo lshw -c display |grep vendor |awk '{print $NF}'")) {
                    displayCard.setDisplayCardVendor(stringBuffer.toString());
                }
                if (command.contains("sudo lshw -c display |grep driver")) {
                    displayCard.setDisplayCardDriver(stringBuffer.toString());
                }
                if (command.contains("sudo lshw -c display |grep clock |awk '{print $NF}'")) {
                    displayCard.setDisplayCardClock(stringBuffer.toString());
                }
            }
        } catch (IOException | JSchException e) {
            e.printStackTrace();
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (channel != null) {
                channel.disconnect();
            }
        }
        return displayCard;
    }

    //退出SSH连接
    public static void disconnect(){
        session.disconnect();
    }
}
