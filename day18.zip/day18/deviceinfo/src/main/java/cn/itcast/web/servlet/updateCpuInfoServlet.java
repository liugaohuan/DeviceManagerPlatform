package cn.itcast.web.servlet;

import cn.itcast.domain.Cpu;
import cn.itcast.service.CpuService;
import cn.itcast.service.impl.CpuServiceImpl;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

@WebServlet("/updateCpuInfoServlet")
public class updateCpuInfoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置编码格式
        request.setCharacterEncoding("utf-8");

        //获取参数集合
        Map<String, String[]> parameterMap = request.getParameterMap();

        //封装成Cpu对象
        Cpu cpu = new Cpu();

        try {
            BeanUtils.populate(cpu, parameterMap);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        //调用CpuService来更新Cpu信息
        CpuService cs = new CpuServiceImpl();
        cs.updateCpuInfo(cpu);

        //共享数据至deviceList
        response.sendRedirect(request.getContextPath()+"/FindDeviceByPageServlet?currentPage=1&rows=5");
    }
}
