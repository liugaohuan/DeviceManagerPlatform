package cn.itcast.service.impl;

import cn.itcast.dao.impl.MemoryDaoImpl;
import cn.itcast.dao.memoryDao;
import cn.itcast.domain.Memory;
import cn.itcast.service.MemoryService;

public class MemoryServiceImpl implements MemoryService {
    //创建memoryDao对象
    memoryDao md = new MemoryDaoImpl();

    /**
     * 根据memid获取memory信息
     * @param memid
     * @return
     */
    @Override
    public Memory findMemoryByID(String memid) {
        return md.findMemoryByID(Integer.parseInt(memid));
    }

    @Override
    public void updateMemoryInfo(Memory memory) {
        md.updateMemoryInfo(memory);
    }
}
