package cn.itcast.service;

import cn.itcast.domain.*;

import java.util.List;
import java.util.Map;

/**
 *
 * 设备管理的业务接口
 */
public interface DeviceService {

    /**
     * 查询所有设备信息
     * @return
     */
    public List<Device> findAll();


    /**
     * 添加设备信息
     * @param device
     */
    public void addDevice(Device device);

    /**
     * 添加全备的设备信息
     * @param device
     * @param bios
     * @param cpu
     * @param disk
     * @param displayCard
     * @param memory
     * @param netcard
     */
    public void addDevice(Device device, Bios bios, Cpu cpu, Disk disk, DisplayCard displayCard, Memory memory, Netcard netcard);

    /**
     * 根据deviceId来查询设备信息
     * @param deviceId
     * @return
     */
    Device searchDeviceById(String deviceId);

    /**
     * 删除设备信息
     * @param device
     */
    void deleteDevice(Device device);

    /**
     * 更新设备信息
     * @param device
     */
    void updateDevice(Device device);

    /**
     * 返回PageBean对象
     *
     * @param currentPage
     * @param rows
     * @param conditions
     * @return
     */
    PageBean findDeviceByPage(String currentPage, String rows, Map<String, String[]> conditions);
}
