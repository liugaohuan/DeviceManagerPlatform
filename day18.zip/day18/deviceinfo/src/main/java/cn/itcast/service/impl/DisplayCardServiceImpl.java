package cn.itcast.service.impl;

import cn.itcast.dao.DisplayCardDao;
import cn.itcast.dao.impl.DisplayCardDaoImpl;
import cn.itcast.domain.DisplayCard;
import cn.itcast.service.DisplayCardService;

public class DisplayCardServiceImpl implements DisplayCardService {
    //创建DisplayCardDao对象
    DisplayCardDao dcd = new DisplayCardDaoImpl();

    @Override
    public DisplayCard findDisplayCardByID(String discardID) {
        return dcd.findDisplayCardByID(Integer.parseInt(discardID));
    }

    @Override
    public void updateDisplayCardInfo(DisplayCard displayCard) {
        dcd.updateDisplayCardInfo(displayCard);
    }
}
