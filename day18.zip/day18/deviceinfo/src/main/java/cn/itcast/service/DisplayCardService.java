package cn.itcast.service;

import cn.itcast.domain.DisplayCard;

/**
 * 显卡管理的业务接口
 */
public interface DisplayCardService {
    /**
     * 根据discardID来查询显卡信息
     * @param discardID
     * @return
     */
    DisplayCard findDisplayCardByID(String discardID);

    /**
     * 更新DisplayCard信息
     * @param displayCard
     */
    void updateDisplayCardInfo(DisplayCard displayCard);
}
