package cn.itcast.web.servlet;

import cn.itcast.domain.Bios;
import cn.itcast.domain.Cpu;
import cn.itcast.service.BiosService;
import cn.itcast.service.CpuService;
import cn.itcast.service.impl.BiosServiceImpl;
import cn.itcast.service.impl.CpuServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet("/findBiosInfoServlet")
public class findBiosInfoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取Bios的id
        String biosid = request.getParameter("biosid");
        //调用Service查询指定biosid的bios信息
        BiosService bs = new BiosServiceImpl();
        Bios bios = bs.findBiosByID(biosid);

        //将bios存入request域中
        request.setAttribute("bios",bios);

        //转发到biosinfo.jsp页面中
        request.getRequestDispatcher("/biosInfo.jsp").forward(request,response);
    }
}
