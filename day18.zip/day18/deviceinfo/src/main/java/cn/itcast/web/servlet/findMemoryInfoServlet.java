package cn.itcast.web.servlet;

import cn.itcast.domain.Memory;
import cn.itcast.service.MemoryService;
import cn.itcast.service.impl.MemoryServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet("/findMemoryInfoServlet")
public class findMemoryInfoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取memory的id
        String memid = request.getParameter("memid");

        //调用service查询指定memid的memory信息
        MemoryService ms = new MemoryServiceImpl();
        Memory memory = ms.findMemoryByID(memid);

        //将memory存入request域中
        request.setAttribute("memory",memory);
        //转发到memoryinfo.jsp页面中
        request.getRequestDispatcher("/memoryInfo.jsp").forward(request,response);
    }
}
