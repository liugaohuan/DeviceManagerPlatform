package cn.itcast.domain;

public class Device {
    private int devId;
    private String assertNumber;
    private String address;
    private String devVendor;
    private String devModel;
    private String osVersion;
    private String owner;
    private String user;
    private String memorySize;
    private int cpuId;
    private String cpuModel;
    private int memId;
    private String memoryModel;
    private int biosId;
    private String biosVendor;
    private int netcardId;
    private String netcardModel;
    private int displayCardId;
    private String displayCardModel;
    private int diskId;
    private String diskModel;



    public Device() {
    }

    public int getDevId() {
        return devId;
    }

    public void setDevId(int devId) {
        this.devId = devId;
    }

    public String getAssertNumber() {
        return assertNumber;
    }

    public void setAssertNumber(String assertNumber) {
        this.assertNumber = assertNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDevVendor() {
        return devVendor;
    }

    public void setDevVendor(String devVendor) {
        this.devVendor = devVendor;
    }

    public String getDevModel() {
        return devModel;
    }

    public void setDevModel(String devModel) {
        this.devModel = devModel;
    }

    public String getOsVersion() {
        return osVersion;
    }

    public void setOsVersion(String osVersion) {
        this.osVersion = osVersion;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getMemorySize() {
        return memorySize;
    }

    public void setMemorySize(String memorySize) {
        this.memorySize = memorySize;
    }

    public int getCpuId() {
        return cpuId;
    }

    public void setCpuId(int cpuId) {
        this.cpuId = cpuId;
    }

    public String getCpuModel() {
        return cpuModel;
    }

    public void setCpuModel(String cpuModel) {
        this.cpuModel = cpuModel;
    }

    public int getMemId() {
        return memId;
    }

    public void setMemId(int memId) {
        this.memId = memId;
    }

    public String getMemoryModel() {
        return memoryModel;
    }

    public void setMemoryModel(String memoryModel) {
        this.memoryModel = memoryModel;
    }

    public int getBiosId() {
        return biosId;
    }

    public void setBiosId(int biosId) {
        this.biosId = biosId;
    }

    public String getBiosVendor() {
        return biosVendor;
    }

    public void setBiosVendor(String biosVendor) {
        this.biosVendor = biosVendor;
    }

    public int getNetcardId() {
        return netcardId;
    }

    public void setNetcardId(int netcardId) {
        this.netcardId = netcardId;
    }

    public String getNetcardModel() {
        return netcardModel;
    }

    public void setNetcardModel(String netcardModel) {
        this.netcardModel = netcardModel;
    }

    public int getDisplayCardId() {
        return displayCardId;
    }

    public void setDisplayCardId(int displayCardId) {
        this.displayCardId = displayCardId;
    }

    public String getDisplayCardModel() {
        return displayCardModel;
    }

    public void setDisplayCardModel(String displayCardModel) {
        this.displayCardModel = displayCardModel;
    }

    public int getDiskId() {
        return diskId;
    }

    public void setDiskId(int diskId) {
        this.diskId = diskId;
    }

    public String getDiskModel() {
        return diskModel;
    }

    public void setDiskModel(String diskModel) {
        this.diskModel = diskModel;
    }

    @Override
    public String toString() {
        return "Device{" +
                "devId=" + devId +
                ", assertNumber='" + assertNumber + '\'' +
                ", address='" + address + '\'' +
                ", devVendor='" + devVendor + '\'' +
                ", devModel='" + devModel + '\'' +
                ", osVersion='" + osVersion + '\'' +
                ", owner='" + owner + '\'' +
                ", user='" + user + '\'' +
                ", memorySize='" + memorySize + '\'' +
                ", cpuId=" + cpuId +
                ", cpuModel='" + cpuModel + '\'' +
                ", memId=" + memId +
                ", memoryModel='" + memoryModel + '\'' +
                ", biosId=" + biosId +
                ", biosVendor='" + biosVendor + '\'' +
                ", netcardId=" + netcardId +
                ", netcardModel='" + netcardModel + '\'' +
                ", displayCardId=" + displayCardId +
                ", displayCardModel='" + displayCardModel + '\'' +
                ", diskId=" + diskId +
                ", diskModel='" + diskModel + '\'' +
                '}';
    }
}
