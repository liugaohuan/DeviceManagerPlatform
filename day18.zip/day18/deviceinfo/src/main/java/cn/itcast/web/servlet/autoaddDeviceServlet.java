package cn.itcast.web.servlet;

import cn.itcast.domain.*;
import cn.itcast.service.DeviceService;
import cn.itcast.service.impl.DeviceServiceImpl;
import cn.itcast.util.DevInfoUtils;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/autoaddDeviceServlet")
public class autoaddDeviceServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.设置编码
        request.setCharacterEncoding("utf-8");

        //2.获取用户输入的参数
        String username = request.getParameter("userName");
        String password = request.getParameter("password");
        String ipaddress = request.getParameter("ipAddress");

        //3. 连接服务器设备
        DevInfoUtils.connect(username,password,ipaddress);

        //3. 封装成Device对象
        Device device = DevInfoUtils.getDevInfo(DevInfoUtils.DEVCOMMANDS);
        System.out.println(device);
        Bios bios = DevInfoUtils.getBiosInfo(DevInfoUtils.BIOSCOMMANDS);
        Netcard netcard = DevInfoUtils.getNetcardInfo(DevInfoUtils.NETWORKCOMMANDS);
        Memory memory = DevInfoUtils.getMemoryInfo(DevInfoUtils.MEMORYCOMMANDS);
        Disk disk = DevInfoUtils.getDiskInfo(DevInfoUtils.DISKCOMMANDS);
        DisplayCard displayCard = DevInfoUtils.getDisplayCardInfo(DevInfoUtils.DISPLAYCOMMANDS);
        Cpu cpu = DevInfoUtils.getCpuInfo(DevInfoUtils.CPUCOMMANDS);

        DevInfoUtils.disconnect();

        //4. 调用Service保存设备信息
        DeviceService ds = new DeviceServiceImpl();
        ds.addDevice(device,bios,cpu,disk,displayCard,memory,netcard);

        //5. 跳转到deviceListServlet
        response.sendRedirect(request.getContextPath()+"/FindDeviceByPageServlet?currentPage=1&rows=5");
    }
}
