package cn.itcast.domain;

public class Netcard {
    private int netcardID;
    private String netcardModel;
    private String netcardSpeed;
    private String netcardVendor;
    private String netcardDriver;
    private String netcardFirmware;
    private String netcardMacAddress;

    public Netcard() {
    }

    public int getNetcardID() {
        return netcardID;
    }

    public void setNetcardID(int netcardID) {
        this.netcardID = netcardID;
    }

    public String getNetcardModel() {
        return netcardModel;
    }

    public void setNetcardModel(String netcardModel) {
        this.netcardModel = netcardModel;
    }

    public String getNetcardSpeed() {
        return netcardSpeed;
    }

    public void setNetcardSpeed(String netcardSpeed) {
        this.netcardSpeed = netcardSpeed;
    }

    public String getNetcardVendor() {
        return netcardVendor;
    }

    public void setNetcardVendor(String netcardVendor) {
        this.netcardVendor = netcardVendor;
    }

    public String getNetcardDriver() {
        return netcardDriver;
    }

    public void setNetcardDriver(String netcardDriver) {
        this.netcardDriver = netcardDriver;
    }

    public String getNetcardFirmware() {
        return netcardFirmware;
    }

    public void setNetcardFirmware(String netcardFirmware) {
        this.netcardFirmware = netcardFirmware;
    }

    public String getNetcardMacAddress() {
        return netcardMacAddress;
    }

    public void setNetcardMacAddress(String netcardMacAddress) {
        this.netcardMacAddress = netcardMacAddress;
    }

    @Override
    public String toString() {
        return "Netcard{" +
                "netcardID=" + netcardID +
                ", netcardModel='" + netcardModel + '\'' +
                ", netcardSpeed='" + netcardSpeed + '\'' +
                ", netcardVendor='" + netcardVendor + '\'' +
                ", netcardDriver='" + netcardDriver + '\'' +
                ", netcardFirmware='" + netcardFirmware + '\'' +
                ", netcardMacAddress='" + netcardMacAddress + '\'' +
                '}';
    }
}
