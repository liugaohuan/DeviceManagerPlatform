package cn.itcast.dao.impl;

import cn.itcast.dao.DiskDao;
import cn.itcast.domain.Disk;
import cn.itcast.util.JDBCUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

public class DiskDaoImpl implements DiskDao {
    //声明一个JDBCTemplate
    private  final JdbcTemplate template = new JdbcTemplate(JDBCUtils.getDataSource());

    @Override
    public Disk findDiskByID(int diskid) {
        //定义SQL语句
        String sql = "select diskid,DiskModel,DiskVendor,DiskCapacity,DiskType,DiskInterface,DiskIdentifier,DisklabelType from DiskInfo where diskid=? ";
        return template.queryForObject(sql,new BeanPropertyRowMapper<Disk>(Disk.class),diskid);
    }

    @Override
    public void updateDiskInfo(Disk disk) {
        //定义sql
        String sql = "update DiskInfo set DiskModel = ?, DiskVendor = ?, DiskCapacity = ?, DiskType = ?, DiskInterface = ?, DiskIdentifier = ?, DisklabelType = ? where diskid = ?";
        template.update(sql, disk.getDiskModel(), disk.getDiskVendor(), disk.getDiskCapacity(), disk.getDiskType(), disk.getDiskInterface(), disk.getDiskIdentifier(), disk.getDiskLabelType(), disk.getDiskId());
    }
}
