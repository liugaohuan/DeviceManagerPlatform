package cn.itcast.service;

import cn.itcast.domain.Disk;

/**
 * 磁盘管理的业务接口
 */
public interface DiskService {
    /**
     * 根据磁盘id查询磁盘详细信息
     * @param diskid
     * @return
     */
    public Disk findDiskByID(String diskid);


    /**
     * 更新disk信息
     * @param disk
     */
    void updateDiskInfo(Disk disk);
}
