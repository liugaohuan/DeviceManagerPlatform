package cn.itcast.dao;

import cn.itcast.domain.*;

import java.util.List;
import java.util.Map;

/*
设备操作的DAO
 */
public interface DeviceDao {

    /**
     * 查询所有设备信息
     * @return
     */
    public List<Device> findAll();


    /**
     * 保存device对象
     * @param device
     */
    public void add(Device device);

    /**
     * 保存Device对象、同时保存其他对象的信息
     * @param device
     * @param bios
     * @param cpu
     * @param disk
     * @param displayCard
     * @param memory
     * @param netcard
     */
    public void add(Device device, Bios bios, Cpu cpu, Disk disk, DisplayCard displayCard, Memory memory, Netcard netcard);

    /**
     * 根据deviceId删除设备信息
     * @param deviceId
     * @return
     */
    Device searchDeviceById(String deviceId);

    /**
     * 删除设备接口
     * @param device
     */
    void deleteDevice(Device device);

    /**
     * 更新设备信息接口
     * @param device
     */
    void updateDevice(Device device);

    /**
     * 返回PageBean对象
     *
     * @param start
     * @param rows
     * @param conditions
     * @return
     */
    List<Device> findByPage(int start, int rows, Map<String, String[]> conditions);

    /**
     * 查询totalCount总记录数
     * @return
     */
    int findTotalCount(Map<String, String[]> conditions);
}
