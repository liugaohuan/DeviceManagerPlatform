package cn.itcast.service;

import cn.itcast.domain.Bios;

/**
 * Bios管理的业务接口
 */
public interface BiosService {
    /**
     * 根据biosID获取bios信息
     * @param biosID
     * @return
     */
    public Bios findBiosByID(String biosID);

    /**
     * 更新bios信息
     * @param bios
     */
    void updateBiosInfo(Bios bios);
}
