package cn.itcast.web.servlet;

import cn.itcast.domain.Device;
import cn.itcast.service.DeviceService;
import cn.itcast.service.impl.DeviceServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet("/findDeviceServlet")
public class findDeviceServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取device的id
        String id = request.getParameter("deviceid");
        //调用Service查询指定ID的设备信息
        DeviceService ds = new DeviceServiceImpl();
        Device device = ds.searchDeviceById(id);

        //将device存入request
        request.setAttribute("device",device);
        //转发到update.jsp页面中
        request.getRequestDispatcher("/updateDevice.jsp").forward(request,response);
    }
}
