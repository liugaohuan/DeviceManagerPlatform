package cn.itcast.dao.impl;

import cn.itcast.dao.DisplayCardDao;
import cn.itcast.domain.DisplayCard;
import cn.itcast.util.JDBCUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

public class DisplayCardDaoImpl implements DisplayCardDao {
    //声明一个JDBCTemplate
    private  final JdbcTemplate template = new JdbcTemplate(JDBCUtils.getDataSource());

    @Override
    public DisplayCard findDisplayCardByID(int discardID) {
        String sql = "select DisplayCardId, DisplayCardModel, DisplayCardVendor, DisplayCardDriver, DisplayCardClock from DisplayCardInfo where DisplayCardId=?";
        return template.queryForObject(sql,new BeanPropertyRowMapper<DisplayCard>(DisplayCard.class),discardID);
    }

    @Override
    public void updateDisplayCardInfo(DisplayCard displayCard) {
        String sql = "update DisplayCardInfo set DisplayCardModel = ?, DisplayCardVendor = ?, DisplayCardDriver = ?, DisplayCardClock = ? where DisplayCardId = ?";
        template.update(sql, displayCard.getDisplayCardModel(), displayCard.getDisplayCardVendor(), displayCard.getDisplayCardDriver(), displayCard.getDisplayCardClock(), displayCard.getDisplayCardId());
    }
}
