package cn.itcast.dao;

import cn.itcast.domain.Memory;

public interface memoryDao {
    /**
     * 根据memid查询memory详细信息
     * @param memid
     * @return
     */
    Memory findMemoryByID(int memid);

    /**
     * 更新内存信息
     * @param memory
     */
    void updateMemoryInfo(Memory memory);
}
