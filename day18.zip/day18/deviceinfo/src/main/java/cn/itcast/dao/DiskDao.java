package cn.itcast.dao;
import cn.itcast.domain.Disk;

/**
 * 磁盘操作的DAO
 */
public interface DiskDao {
    /**
     * 根据磁盘型号查询磁盘详细信息
     * @param diskid
     * @return
     */
    Disk findDiskByID(int diskid);

    /**
     * 更新磁盘信息
     * @param disk
     */
    void updateDiskInfo(Disk disk);
}
