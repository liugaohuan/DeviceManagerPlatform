package cn.itcast.domain;

import java.util.Date;

public class Bios {
    private int biosId;
    private String biosVendor;
    private String biosVersion;
    private String releaseDate;
    private String rowSize;
    private String address;

    public Bios() {
    }

    public int getBiosId() {
        return biosId;
    }

    public void setBiosId(int biosId) {
        this.biosId = biosId;
    }

    public String getBiosVendor() {
        return biosVendor;
    }

    public void setBiosVendor(String biosVendor) {
        this.biosVendor = biosVendor;
    }

    public String getBiosVersion() {
        return biosVersion;
    }

    public void setBiosVersion(String biosVersion) {
        this.biosVersion = biosVersion;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getRowSize() {
        return rowSize;
    }

    public void setRowSize(String rowSize) {
        this.rowSize = rowSize;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Bios{" +
                "biosId=" + biosId +
                ", biosVendor='" + biosVendor + '\'' +
                ", biosVersion='" + biosVersion + '\'' +
                ", releaseDate=" + releaseDate +
                ", rowSize='" + rowSize + '\'' +
                ", address='" + address + '\'' +
                '}';
    }
}
