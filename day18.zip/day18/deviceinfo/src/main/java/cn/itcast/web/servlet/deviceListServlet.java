package cn.itcast.web.servlet;

import cn.itcast.domain.Device;
import cn.itcast.service.DeviceService;
import cn.itcast.service.impl.DeviceServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/deviceListServlet")
public class deviceListServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //调用DeviceService完成查询
        DeviceService ds = new DeviceServiceImpl();
        List<Device> devices = ds.findAll();

        //将list存入request域中
        request.setAttribute("devices",devices);

        //转发到list.jsp中
        request.getRequestDispatcher("/list.jsp").forward(request,response);
    }
}
