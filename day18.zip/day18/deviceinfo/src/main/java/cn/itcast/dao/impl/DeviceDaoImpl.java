package cn.itcast.dao.impl;

import cn.itcast.dao.DeviceDao;
import cn.itcast.domain.*;
import cn.itcast.util.JDBCUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class DeviceDaoImpl implements DeviceDao {

    //声明一个JdbcTemplate
    private final JdbcTemplate template = new JdbcTemplate(JDBCUtils.getDataSource());

    @Override
    public List<Device> findAll() {

        //使用jdbc操作数据库
        //定义sql语句
        String sql = "select  DevInfo.devid,DevInfo.assertNumber,DevInfo.devVendor, DevInfo.devModel,DevInfo.osVersion, `owner`,`user`, DevInfo.address,CI.cpuid, CI.cpuModel,MI.memid,MI.memoryModel, DevInfo.memorySize, BI.biosid,BI.biosVendor,  NCI.netcardid, NCI.NetCardModel,DI.diskid, DI.diskModel,DCI.DisplayCardId, DCI.DisplayCardModel from DevInfo left join BiosInfo BI on BI.biosid = DevInfo.biosid left join CpuInfo CI on CI.cpuid = DevInfo.cpuid left join MemoryInfo MI on DevInfo.memid = MI.memid left join NetCardInfo NCI on DevInfo.netcardid = NCI.netCardID left join DiskInfo DI on DevInfo.diskid = DI.diskid left join DisplayCardInfo DCI on DevInfo.displaycardid = DCI.DisplayCardId;";
        List<Device> devices = template.query(sql, new BeanPropertyRowMapper<Device>(Device.class));
        return devices;
    }

    @Override
    public void add(Device device) {

        //定义sql语句
        //更新BiosInfo表
        String biosSql = "insert into BiosInfo values(null,?,null,null,null,null)";
        template.update(biosSql,device.getBiosVendor());

        //更新CpuInfo表
        String cpuSql = "insert into CpuInfo values(null,?,null,null,null,null,null,null,null,null)";
        template.update(cpuSql,device.getCpuModel());

        //更新DiskInfo表
        String diskSql = "insert into DiskInfo values(null,?,null,null,null,null,null,null)";
        template.update(diskSql,device.getDiskModel());

        //更新DisplayCardInfo表
        String displayCardSql = "insert into DisplayCardInfo values(null,?,null,null,null)";
        template.update(displayCardSql,device.getDisplayCardModel());

        //更新MemoryInfo表
        String meminfoSql = "insert into MemoryInfo values(null,?,null,null,null,null,null)";
        template.update(meminfoSql,device.getMemoryModel());

        //更新NetCardInfo表
        String netcardSql = "insert into NetCardInfo values(null,?,null,null,null,null,null)";
        template.update(netcardSql,device.getNetcardModel());

        //获取以上表最大的id
        String maxBiosIDSql = "select max(biosid) from BiosInfo";
        Map<String, Object> stringBiosMap = template.queryForMap(maxBiosIDSql);
        for (Map.Entry<String, Object> entry : stringBiosMap.entrySet()) {
            device.setBiosId((Integer) entry.getValue());
        }

        String maxCpuIDSql = "select max(cpuid) from CpuInfo";
        Map<String, Object> stringCpuMap = template.queryForMap(maxCpuIDSql);
        for(Map.Entry<String, Object> entry : stringCpuMap.entrySet()){
            device.setCpuId((Integer) entry.getValue());
        }

        String maxDiskIDSql = "select max(diskid) from DiskInfo";
        Map<String, Object> stringDiskMap = template.queryForMap(maxDiskIDSql);
        for(Map.Entry<String, Object> entry : stringDiskMap.entrySet()){
            device.setDiskId((Integer) entry.getValue());
        }

        String maxDisCardIDSql = "select max(DisplayCardId) from DisplayCardInfo";
        Map<String, Object> stringDisplayCardMap = template.queryForMap(maxDisCardIDSql);
        for(Map.Entry<String, Object> entry : stringDisplayCardMap.entrySet()){
            device.setDisplayCardId((Integer) entry.getValue());
        }

        String maxMemIDSql = "select max(memid) from MemoryInfo";
        Map<String, Object> stringMemoryMap = template.queryForMap(maxMemIDSql);
        for(Map.Entry<String, Object> entry : stringMemoryMap.entrySet()){
            device.setMemId((Integer) entry.getValue());
        }

        String maxNetCardIDSql = "select max(netCardID) from NetCardInfo";
        Map<String, Object> stringNetcardMap = template.queryForMap(maxNetCardIDSql);
        for(Map.Entry<String, Object> entry : stringNetcardMap.entrySet()){
            device.setNetcardId((Integer) entry.getValue());
        }

        //更新DevInfo表
        String devSql = "insert into DevInfo values(null,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        template.update(devSql,device.getAssertNumber(),device.getAddress(),device.getDevVendor(),device.getDevModel(),device.getOsVersion(),device.getOwner(),
               device.getUser(),device.getMemorySize(),device.getCpuId(), device.getMemId(),device.getBiosId(),device.getNetcardId(),device.getDiskId(),device.getDisplayCardId());
    }

    @Override
    public void add(Device device, Bios bios, Cpu cpu, Disk disk, DisplayCard displayCard, Memory memory, Netcard netcard) {
        //定义sql语句
        //更新BiosInfo表
        String biosSql = "insert into BiosInfo values(null,?,?,?,?,?)";
        template.update(biosSql,device.getBiosVendor(),bios.getBiosVersion(),bios.getReleaseDate(),bios.getRowSize(),bios.getAddress());

        //更新CpuInfo表
        String cpuSql = "insert into CpuInfo values(null,?,?,?,?,?,?,?,?,?)";
        template.update(cpuSql,device.getCpuModel(),cpu.getmHz(),cpu.getCores(),cpu.getNumaNodes(),cpu.getVendor(),cpu.getL1dCache(),cpu.getL1iCache(),cpu.getL2Cache(),cpu.getL3Cache());

        //更新DiskInfo表
        String diskSql = "insert into DiskInfo values(null,?,?,?,?,?,?,?)";
        template.update(diskSql,device.getDiskModel(),disk.getDiskVendor(),disk.getDiskCapacity(),disk.getDiskType(),disk.getDiskInterface(),disk.getDiskIdentifier(),disk.getDiskLabelType());

        //更新DisplayCardInfo表
        String displayCardSql = "insert into DisplayCardInfo values(null,?,?,?,?)";
        template.update(displayCardSql,device.getDisplayCardModel(),displayCard.getDisplayCardVendor(),displayCard.getDisplayCardDriver(),displayCard.getDisplayCardClock());

        //更新MemoryInfo表
        String meminfoSql = "insert into MemoryInfo values(null,?,?,?,?,?,?)";
        template.update(meminfoSql,device.getMemoryModel(),memory.getMemoryVendor(),memory.getMemoryClock(),memory.getMemorySize(),memory.getMemoryDDR(),memory.getMemorySpeed());

        //更新NetCardInfo表
        String netcardSql = "insert into NetCardInfo values(null,?,?,?,?,?,?)";
        template.update(netcardSql,device.getNetcardModel(),netcard.getNetcardSpeed(),netcard.getNetcardVendor(),netcard.getNetcardDriver(),netcard.getNetcardFirmware(),netcard.getNetcardMacAddress());

        //获取以上表最大的id
        String maxBiosIDSql = "select max(biosid) from BiosInfo";
        Map<String, Object> stringBiosMap = template.queryForMap(maxBiosIDSql);
        for (Map.Entry<String, Object> entry : stringBiosMap.entrySet()) {
            device.setBiosId((Integer) entry.getValue());
        }

        String maxCpuIDSql = "select max(cpuid) from CpuInfo";
        Map<String, Object> stringCpuMap = template.queryForMap(maxCpuIDSql);
        for(Map.Entry<String, Object> entry : stringCpuMap.entrySet()){
            device.setCpuId((Integer) entry.getValue());
        }

        String maxDiskIDSql = "select max(diskid) from DiskInfo";
        Map<String, Object> stringDiskMap = template.queryForMap(maxDiskIDSql);
        for(Map.Entry<String, Object> entry : stringDiskMap.entrySet()){
            device.setDiskId((Integer) entry.getValue());
        }

        String maxDisCardIDSql = "select max(DisplayCardId) from DisplayCardInfo";
        Map<String, Object> stringDisplayCardMap = template.queryForMap(maxDisCardIDSql);
        for(Map.Entry<String, Object> entry : stringDisplayCardMap.entrySet()){
            device.setDisplayCardId((Integer) entry.getValue());
        }

        String maxMemIDSql = "select max(memid) from MemoryInfo";
        Map<String, Object> stringMemoryMap = template.queryForMap(maxMemIDSql);
        for(Map.Entry<String, Object> entry : stringMemoryMap.entrySet()){
            device.setMemId((Integer) entry.getValue());
        }

        String maxNetCardIDSql = "select max(netCardID) from NetCardInfo";
        Map<String, Object> stringNetcardMap = template.queryForMap(maxNetCardIDSql);
        for(Map.Entry<String, Object> entry : stringNetcardMap.entrySet()){
            device.setNetcardId((Integer) entry.getValue());
        }

        //更新DevInfo表
        String devSql = "insert into DevInfo values(null,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        template.update(devSql,device.getAssertNumber(),device.getAddress(),device.getDevVendor(),device.getDevModel(),device.getOsVersion(),device.getOwner(),
                device.getUser(),device.getMemorySize(),device.getCpuId(), device.getMemId(),device.getBiosId(),device.getNetcardId(),device.getDiskId(),device.getDisplayCardId());
    }


    @Override
    public Device searchDeviceById(String deviceId) {
        //定义sql语句
        String sql = "select  DevInfo.devid, DevInfo.assertNumber, DevInfo.devVendor, DevInfo.devModel,DevInfo.osVersion, `owner`,`user`, DevInfo.address,CI.cpuid, CI.cpuModel,MI.memid,MI.memoryModel, DevInfo.memorySize, BI.biosid,BI.biosVendor,  NCI.netcardid, NCI.NetCardModel,DI.diskid, DI.diskModel,DCI.DisplayCardId, DCI.DisplayCardModel from DevInfo left join BiosInfo BI on BI.biosid = DevInfo.biosid left join CpuInfo CI on CI.cpuid = DevInfo.cpuid left join MemoryInfo MI on DevInfo.memid = MI.memid left join NetCardInfo NCI on DevInfo.netcardid = NCI.netCardID left join DiskInfo DI on DevInfo.diskid = DI.diskid left join DisplayCardInfo DCI on DevInfo.displaycardid = DCI.DisplayCardId WHERE DevInfo.DevID = ?";
        return template.queryForObject(sql,new BeanPropertyRowMapper<Device>(Device.class),deviceId);
    }

    @Override
    public void deleteDevice(Device device) {
        //定义sql语句，删除设备记录
        String deleteDevSql = "delete from DevInfo where DevID=?";
        template.update(deleteDevSql, device.getDevId());

        //同时删除对应父表:CpuInfo、MemoryInfo、BiosInfo、NetcardInfo、DiskInfo、DisplayCardInfo表中指定的记录
        String deleteCpuSql = "delete from CpuInfo where cpuid=?";
        template.update(deleteCpuSql, device.getCpuId());

        String deleteMemorySql = "delete from MemoryInfo where memid = ?";
        template.update(deleteMemorySql, device.getMemId());

        String deleteBiosSql = "delete from BiosInfo where biosid = ?";
        template.update(deleteBiosSql, device.getBiosId());

        String deleteNetcardSql = " delete from NetCardInfo where netCardID = ?";
        template.update(deleteNetcardSql, device.getNetcardId());

        String deleteDiskSql = "delete from DiskInfo where diskid = ?";
        template.update(deleteDiskSql, device.getDiskId());

        String deleteDisplayCardSql = " delete from DisplayCardInfo where DisplayCardId =?";
        template.update(deleteDisplayCardSql, device.getDisplayCardId());
    }

    @Override
    public void updateDevice(Device device) {
        //定义sql语句
        String updateBiosSql = "update BiosInfo set biosVendor = ? where biosid = ? ";
        template.update(updateBiosSql, device.getBiosVendor(), device.getBiosId());

        String updateCpuSql = "update CpuInfo set CpuModel = ? where cpuid = ? ";
        template.update(updateCpuSql, device.getCpuModel(), device.getCpuId());

        String updateDiskSql = "update DiskInfo set DiskModel = ? where diskid = ?";
        template.update(updateDiskSql, device.getDiskModel(), device.getDiskId());

        String updateDisplayCardSql = "update DisplayCardInfo set DisplayCardModel = ? where DisplayCardid = ?";
        template.update(updateDisplayCardSql, device.getDisplayCardModel(), device.getDisplayCardModel());

        String updateMemorySql = "update MemoryInfo set memoryModel = ? where memid = ?";
        template.update(updateMemorySql, device.getMemoryModel(), device.getMemId());

        String updateNetcardSql = "update NetCardInfo set NetCardModel = ? where netCardID = ?";
        template.update(updateNetcardSql, device.getNetcardModel(), device.getNetcardId());

        String updateDeviceSql = "update DevInfo set AssertNumber = ?, Address=?, DevVendor=?, DevModel=?, osVersion=?, Owner=?, User=? , memorySize=? where DevID=?";
        template.update(updateDeviceSql, device.getAssertNumber(), device.getAddress(), device.getDevVendor(), device.getDevModel(), device.getOsVersion(), device.getOwner(), device.getUser(), device.getMemorySize(), device.getDevId());
    }

    @Override
    public List<Device> findByPage(int start, int rows, Map<String, String[]> conditions) {
        //定义模板初始化sql
        String sql = "select DevInfo.devid,DevInfo.assertNumber,DevInfo.devVendor, DevInfo.devModel,DevInfo.osVersion, " +
                "`owner`,`user`, DevInfo.address,CI.cpuid, CI.cpuModel,MI.memid,MI.memoryModel, DevInfo.memorySize, " +
                "BI.biosid,BI.biosVendor,  NCI.netcardid, NCI.NetCardModel,DI.diskid, DI.diskModel,DCI.DisplayCardId, " +
                "DCI.DisplayCardModel from DevInfo left join BiosInfo BI on BI.biosid = DevInfo.biosid left join CpuInfo CI on CI.cpuid = DevInfo.cpuid " +
                "left join MemoryInfo MI on DevInfo.memid = MI.memid" +
                " left join NetCardInfo NCI on DevInfo.netcardid = NCI.netCardID left join DiskInfo DI on DevInfo.diskid = DI.diskid " +
                "left join DisplayCardInfo DCI on DevInfo.displaycardid = DCI.DisplayCardId where 1 = 1 ";
        StringBuilder sb = new StringBuilder(sql);
        //定义参数的集合，用来存储sql里占位符的数据
        List<Object> params = new ArrayList<Object>();
//        遍历map集合
        Set<String> keySet = conditions.keySet();
        for(String key: keySet){
            if("currentPage".equals(key) || "rows".equals(key)){
                continue;
            }
            //获取value
            String value = conditions.get(key)[0];
            //判断value是否有数据
            if(value != null && !"".equals(value)){
                sb.append(" and "+key+" like ?");
                params.add("%"+value+"%");
            }
        }
        String finalSql = sb.toString()+"limit ?,?";
        params.add(start);
        params.add(rows);
        return template.query(finalSql, new BeanPropertyRowMapper<Device>(Device.class), params.toArray());
    }

    @Override
    public int findTotalCount(Map<String, String[]> conditions) {
        //定义模板初始化sql
        String sql = "select count(*) from DevInfo where 1 = 1";
        StringBuilder sb = new StringBuilder(sql);
        //遍历map集合
        Set<String> keySet = conditions.keySet();
        //定义参数的集合
        List<Object> params = new ArrayList<Object>();
        for(String key: keySet){
            if("currentPage".equals(key) || "rows".equals(key)){
                continue;
            }
            //获取value
            String value = conditions.get(key)[0];
            //判断value是否有数据
            if(value != null && !"".equals(value)){
                sb.append(" and "+key+" like ?");
                params.add("%"+value+"%");
            }
        }
        return template.queryForObject(sb.toString(),  Integer.class,  params.toArray());
    }
}