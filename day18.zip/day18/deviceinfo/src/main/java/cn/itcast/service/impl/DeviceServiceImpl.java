package cn.itcast.service.impl;

import cn.itcast.dao.DeviceDao;
import cn.itcast.dao.impl.DeviceDaoImpl;
import cn.itcast.domain.*;
import cn.itcast.service.DeviceService;
import java.util.List;
import java.util.Map;

public class DeviceServiceImpl implements DeviceService {

    //创建DeviceDao实现类对象
    DeviceDao dd = new DeviceDaoImpl();

    /**
     * 获取所有设备列表
     * @return
     */
    @Override
    public List<Device> findAll() {
        //调用dao完成查询
       return dd.findAll();
    }


    /**
     * 添加设备信息接口
     * @param device
     */
    @Override
    public void addDevice(Device device) {
        dd.add(device);
    }

    @Override
    public void addDevice(Device device, Bios bios, Cpu cpu, Disk disk, DisplayCard displayCard, Memory memory, Netcard netcard) {
        dd.add(device,bios,cpu,disk,displayCard,memory,netcard);
    }


    /**设备id来删除设备信息
     * 根据设备
     * @param deviceId
     * @return
     */
    @Override
    public Device searchDeviceById(String deviceId) {
        return dd.searchDeviceById(deviceId);
    }

    @Override
    public void deleteDevice(Device device) {
        dd.deleteDevice(device);
    }

    /**
     * 更新设备信息
     * @param device
     */
    @Override
    public void updateDevice(Device device) {
        dd.updateDevice(device);
    }

    /**
     * 返回PageBean对象
     *
     * @param _currentPage
     * @param _rows
     * @param conditions
     * @return
     */
    @Override
    public PageBean<Device> findDeviceByPage(String _currentPage, String _rows, Map<String, String[]> conditions) {
        //创建空的PageBean对象
        PageBean<Device> pb = new PageBean<Device>();
        //为pagebean赋值
        int currentPage = Integer.parseInt(_currentPage);
        int rows = Integer.parseInt(_rows);
        pb.setCurrentPage(currentPage);
        pb.setRows(rows);
        //调用dao查询总记录数
        int totalCount = dd.findTotalCount(conditions);
        //设置pb对象的总记录数
        pb.setTotalCount(totalCount);
        //计算开始行数
        int start = (currentPage -1 ) * rows;
        List<Device> list = dd.findByPage(start, rows, conditions);
        //设置pb对象的list
        pb.setList(list);

        //计算总页码
         int pageNumber = (totalCount % rows == 0) ? totalCount/rows:(totalCount/rows+1);
         //设置总页码
        pb.setTotalPage(pageNumber);
        //返回pb对象
        return pb;
    }
}
