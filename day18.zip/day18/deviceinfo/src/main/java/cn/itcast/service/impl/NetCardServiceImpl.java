package cn.itcast.service.impl;

import cn.itcast.dao.NetCardDao;
import cn.itcast.dao.impl.NetCardDaoImpl;
import cn.itcast.domain.Netcard;
import cn.itcast.service.NetCardService;

public class NetCardServiceImpl implements NetCardService {

    NetCardDao ncd = new NetCardDaoImpl();

    @Override
    public Netcard findNetCardByID(String netcardid) {
        return ncd.findNetCardByID(Integer.parseInt(netcardid));
    }

    @Override
    public void updateNetcard(Netcard netcard) {
        ncd.updateNetcard(netcard);
    }
}
