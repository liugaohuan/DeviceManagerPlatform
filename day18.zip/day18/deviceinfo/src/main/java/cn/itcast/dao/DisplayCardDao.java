package cn.itcast.dao;

import cn.itcast.domain.DisplayCard;

/**
 * DisplayCard操作的DAO
 */
public interface DisplayCardDao {
    /**
     * 通过discardID查询显卡对象
     * @param discardID
     * @return
     */
    DisplayCard findDisplayCardByID(int discardID);

    /**
     * 更新DisplayCard信息
     * @param displayCard
     */
    void updateDisplayCardInfo(DisplayCard displayCard);
}
