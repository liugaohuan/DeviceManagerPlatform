package cn.itcast.dao;

import cn.itcast.domain.Bios;

/**
 * bios操作的DAO
 */
public interface BiosDao {
    /**
     * 根据biosid查询bios详细信息
     * @param biosid
     * @return
     */
    Bios findBiosByID(int biosid);

    /**
     * 更新Bios信息
     * @param bios
     */
    void updateBiosInfo(Bios bios);
}
