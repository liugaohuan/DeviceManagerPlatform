package cn.itcast.domain;

public class Memory {
    private int memId;
    private String memoryModel;
    private String memoryVendor;
    private String memoryClock;
    private String memorySize;
    private String memoryDDR;
    private String memorySpeed;

    public Memory() {
    }

    public int getMemId() {
        return memId;
    }

    public void setMemId(int memId) {
        this.memId = memId;
    }

    public String getMemoryModel() {
        return memoryModel;
    }

    public void setMemoryModel(String memoryModel) {
        this.memoryModel = memoryModel;
    }

    public String getMemoryVendor() {
        return memoryVendor;
    }

    public void setMemoryVendor(String memoryVendor) {
        this.memoryVendor = memoryVendor;
    }

    public String getMemoryClock() {
        return memoryClock;
    }

    public void setMemoryClock(String memoryClock) {
        this.memoryClock = memoryClock;
    }

    public String getMemorySize() {
        return memorySize;
    }

    public void setMemorySize(String memorySize) {
        this.memorySize = memorySize;
    }

    public String getMemoryDDR() {
        return memoryDDR;
    }

    public void setMemoryDDR(String memoryDDR) {
        this.memoryDDR = memoryDDR;
    }

    public String getMemorySpeed() {
        return memorySpeed;
    }

    public void setMemorySpeed(String memorySpeed) {
        this.memorySpeed = memorySpeed;
    }

    @Override
    public String toString() {
        return "Memory{" +
                "memId=" + memId +
                ", memoryModel='" + memoryModel + '\'' +
                ", memoryVendor='" + memoryVendor + '\'' +
                ", memoryClock='" + memoryClock + '\'' +
                ", memorySize='" + memorySize + '\'' +
                ", memoryDDR='" + memoryDDR + '\'' +
                ", memorySpeed='" + memorySpeed + '\'' +
                '}';
    }
}
