package cn.itcast.web.servlet;

import cn.itcast.domain.Device;
import cn.itcast.service.DeviceService;
import cn.itcast.service.impl.DeviceServiceImpl;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

@WebServlet("/addDeviceServlet")
public class addDeviceServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.设置编码
        request.setCharacterEncoding("utf-8");

        //2.获取参数，返回参数Map集合
        Map<String, String[]> parameterMap = request.getParameterMap();

        //3.封装成device对象
        Device device = new Device();

        try {
            BeanUtils.populate(device,parameterMap);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        //4. 调用Service保存设备信息
        DeviceService ds = new DeviceServiceImpl();
        ds.addDevice(device);

        //5. 跳转到deviceListServlet
        response.sendRedirect(request.getContextPath()+"/FindDeviceByPageServlet?currentPage=1&rows=5");
    }
}
