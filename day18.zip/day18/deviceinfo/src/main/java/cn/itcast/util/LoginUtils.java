package cn.itcast.util;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class LoginUtils {
    public static ArrayList<String> findUsernameAndPassword() {
        //访问文件
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add("admin");
        arrayList.add("deepin12!");
        return arrayList;
    }
}
